package net.javaguides.springboot;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import net.javaguides.springboot.model.Admin;

public class AdminTest {

    private Admin admin;

    @BeforeEach
    public void setUp() {
        admin = new Admin("John Doe", "john@example.com", "1234567890", "123 Main St", "johndoe", "password");
    }

    @Test
    public void testGettersAndSetters() {
        admin.setId(1);
        assertEquals(1, admin.getId());

        admin.setName("Jane Smith");
        assertEquals("Jane Smith", admin.getName());

        admin.setEmail("jane@example.com");
        assertEquals("jane@example.com", admin.getEmail());

        admin.setMobile("9876543210");
        assertEquals("9876543210", admin.getMobile());

        admin.setAddress("456 Elm St");
        assertEquals("456 Elm St", admin.getAddress());

        admin.setUsername("janesmith");
        assertEquals("janesmith", admin.getUsername());

        admin.setPassword("newpassword");
        assertEquals("newpassword", admin.getPassword());
    }

    @Test
    public void testToString() {
        String expected = "AdminModel [id=0, name=John Doe, email=john@example.com, mobile=1234567890, address=123 Main St, username=johndoe, password=password]";
        assertEquals(expected, admin.toString());
    }
}
