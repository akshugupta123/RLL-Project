package net.javaguides.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.model.Menu;
import net.javaguides.springboot.model.Menu;
import net.javaguides.springboot.model.TableModel;
import net.javaguides.springboot.model.UserModel;
import net.javaguides.springboot.repository.MenuRepository;
import net.javaguides.springboot.repository.TableRepository;
import net.javaguides.springboot.repository.UserRepository;
@CrossOrigin(origins="*")

@RestController
@RequestMapping("/cafe/user")
public class UserControllerNew {
	@Autowired
	UserRepository userRepository;
	@Autowired
	private MenuRepository menuRepository; 
	  
	@Autowired
	TableRepository tableRepository;
	
	@GetMapping("/registered")
	public List<UserModel> getRegisteredUser() {
		return userRepository.findAll();
	}
	
	@PostMapping("/register")
	public UserModel registeration(@RequestBody UserModel userModel) {
		return userRepository.save(userModel);
	}
	
	@GetMapping("/userlogin")
	public UserModel login(@RequestParam String username,@RequestParam String password) {
	return userRepository.findByUsernameAndPassword(username,password);
	
	}
	
	
	@PutMapping("/update/{userId}")
    public ResponseEntity<UserModel> updateUser(@PathVariable int userId, @Validated @RequestBody UserModel userDetails) throws ResourceNotFoundException {
        UserModel user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found for this id: " + userId));

        user.setName(userDetails.getName());
        user.setEmail(userDetails.getEmail());
        user.setMobile(userDetails.getMobile());
        user.setAddress(userDetails.getAddress());
     // user.setUsername(userDetails.getUsername());
        user.setPassword(userDetails.getPassword());

        final UserModel updatedUser = userRepository.save(user);
        return ResponseEntity.ok(updatedUser);
    }
//	@PutMapping("/change-password/{userId}")
//    public ResponseEntity<UserModel> changePassword(
//            @PathVariable int userId,
//            @RequestParam String oldPassword,
//            @RequestParam String newPassword
//    ) throws ResourceNotFoundException {
//        UserModel user = userRepository.findById(userId)
//                .orElseThrow(() -> new ResourceNotFoundException("User not found for this id: " + userId));
//
//        if (!user.getPassword().equals(oldPassword)) {
//            return ResponseEntity.badRequest().build(); // Return bad request if old password doesn't match
//        }
//
//        user.setPassword(newPassword);
//
//        final UserModel updatedUser = userRepository.save(user);
//        return ResponseEntity.ok(updatedUser);
//    }
//	
	
	 
	
	@GetMapping("/booktable")
	public TableModel bookTable(@RequestParam int id,@RequestParam String username) {
		
		TableModel tm=tableRepository.findById(id);// Retrieve the table by ID
		String status=tm.getTablestatus();// Get the current status of the table
		if(status!="Reserved") { // If the table is not already reserved
			tm.getTableusername();
			tm.setTableusername(username);// Set the reserved username
			tm.setTablestatus("Reserved");// Update the status to "Reserved"
		}
		return tableRepository.save(tm); // Save and return the updated table model
	}
	
	
	@GetMapping("/search-table")
	public List<TableModel> getBookedTable(@RequestParam String tablerow){
		return tableRepository.findByTablerow(tablerow);
		
	}

	@GetMapping("/bookedtables")
	public List<TableModel>getBookedTables(@RequestParam String username){
		return tableRepository.findByTableusername(username);
	}
	
	
	@GetMapping("/menu")
	public List<Menu> getAllMenu(){
		return menuRepository.findAll();
	}	
	
	@GetMapping("/menu/name")
    public ResponseEntity<List<Menu>> getMenuByItemName(@RequestParam String name) {
        List<Menu> menuList = (List<Menu>) menuRepository.findByName(name);

        if (menuList.isEmpty()) {
            throw new ResourceNotFoundException("No menus found with name: " + name);
        }

        return ResponseEntity.ok(menuList);
    }
}


