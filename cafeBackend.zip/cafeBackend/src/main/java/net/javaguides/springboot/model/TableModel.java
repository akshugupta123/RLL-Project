package net.javaguides.springboot.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity //lightweight persistence domain object
public class TableModel {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String tablerow;
	private String tablenumber;
	private String tablecapacity;
	private String tabletype;
	private String tableusername;
	private String tablestatus;
//	public TableModel(String tablenumber, String tablestatus) {
//		// TODO Auto-generated constructor stub
//	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTablerow() {
		return tablerow;
	}
	public void setTablerow(String tablerow) {
		this.tablerow = tablerow;
	}
	public String getTablenumber() {
		return tablenumber;
	}
	public void setTablenumber(String tablenumber) {
		this.tablenumber = tablenumber;
	}
	public String getTablecapacity() {
		return tablecapacity;
	}
	public void setTablecapacity(String tablecapacity) {
		this.tablecapacity = tablecapacity;
	}
	
	public String getTabletype() {
		return tabletype;
	}
	public void setTabletype(String tabletype) {
		this.tabletype = tabletype;
	}
	public String getTableusername() {
		return tableusername;
	}
	public void setTableusername(String tableusername) {
		this.tableusername = tableusername;
	}
	public String getTablestatus() {
		return tablestatus;
	}
	public void setTablestatus(String tablestatus) {
		this.tablestatus = tablestatus;
	}
	@Override
	public String toString() {
	    return "TableModel [id=" + id + ", tablerow=" + tablerow + ", tablenumber=" + tablenumber +
	            ", tablecapacity=" + tablecapacity + ", tabletype=" + tabletype +
	            ", tableusername=" + tableusername + ", tablestatus=" + tablestatus + "]";
	}

	
}
