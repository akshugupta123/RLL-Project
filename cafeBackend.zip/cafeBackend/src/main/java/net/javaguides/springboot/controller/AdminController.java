package net.javaguides.springboot.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.model.Admin;
import net.javaguides.springboot.model.Menu;
import net.javaguides.springboot.model.TableModel;
import net.javaguides.springboot.repository.AdminRepository;
import net.javaguides.springboot.repository.MenuRepository;
import net.javaguides.springboot.repository.TableRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/cafe/api")
public class AdminController {
	
	
	@Autowired
	TableRepository tableRepository;
	
	@Autowired
	private MenuRepository menuRepository; 
	
	@Autowired
    private AdminRepository adminRepository;

	@PostMapping("/register")
    public ResponseEntity<Admin> adminRegistration(@Validated @RequestBody Admin admin) {
        // Check if the admin already exists
        if (adminRepository.existsByUsername(admin.getUsername())) {
            throw new ResourceNotFoundException("Admin with username: " + admin.getUsername() + " already exists");
        }

        Admin savedAdmin = adminRepository.save(admin);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedAdmin);
    }

    // Admin login
    @PostMapping("/login")
    public ResponseEntity<Admin> adminLogin(@RequestParam String username, @RequestParam String password) {
        Admin admin = adminRepository.findByUsernameAndPassword(username, password);
        
        if (admin == null) {
            throw new ResourceNotFoundException("Invalid admin credentials");
        }
        
        return ResponseEntity.ok(admin);
    }

	
	// get all Menus
	@GetMapping("/menu")
	public List<Menu> getAllMenu(){
		return menuRepository.findAll();
	}		
	
	// create Menu rest api
	@PostMapping("/add-menu")
	public Menu createMenu(@RequestBody Menu Menu) {
		return menuRepository.save(Menu);
	}
	
	// get Menu by id rest api
	@GetMapping("/menu/name")
	public ResponseEntity<List<Menu>> getMenuByItemName(@RequestParam String name) {
	    List<Menu> menuList = menuRepository.findByName(name);
	    
	    if (menuList.isEmpty()) {
	        throw new ResourceNotFoundException("No menus found with name: " + name);
	    }
	    
	    return new ResponseEntity<>(menuList, HttpStatus.OK);
	}

	
	// update Menu rest api
	
	@PutMapping("update/{name}")
	public ResponseEntity<Menu> updateMenu(@PathVariable String name, @RequestBody Menu menuDetails) {
	    List<Menu> menuList = menuRepository.findByName(name);

	    if (menuList.isEmpty()) {
	        throw new ResourceNotFoundException("Menu not exist with name: " + name);
	    }
	    
	    Menu existingMenu = menuList.get(0);
	    existingMenu.setName(menuDetails.getName());
	    existingMenu.setItemPrice(menuDetails.getItemPrice());
	    existingMenu.setDescription(menuDetails.getDescription());

	    Menu updatedMenu = menuRepository.save(existingMenu);
	    return ResponseEntity.ok(updatedMenu);
	}

	
	//delete Menu rest api
	// delete Menu rest api
	@DeleteMapping("delete/{name}")
	public ResponseEntity<Map<String, Boolean>> deleteMenu(@PathVariable String name) {
	    List<Menu> menuList = menuRepository.findByName(name);

	    if (!menuList.isEmpty()) {
	        Menu menu = menuList.get(0);
	        menuRepository.delete(menu);

	        Map<String, Boolean> response = new HashMap<>();
	        response.put("deleted", Boolean.TRUE);

	        return ResponseEntity.ok(response);
	    } else {
	        throw new ResourceNotFoundException("Menu not found with name: " + name);
	    }
	}
	
	@GetMapping("getAll/tables")
	public List<TableModel> getAllReservedTables() {
		return tableRepository.findAll();
	}

	
	@PostMapping("/addtables")
	public TableModel saveTables(@Validated @RequestBody TableModel tableModel) {
		tableModel.getTableusername();
		tableModel.setTableusername("waiting");
		tableModel.getTablestatus();
		tableModel.setTablestatus("waiting");
		return tableRepository.save(tableModel);
	}
	
	
}
