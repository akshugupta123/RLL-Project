import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError } from 'rxjs';
import { User } from './usermodel';
import { Menu } from './menu';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpclient: HttpClient) { }

  getUserLogin(username: string, password: string): Observable<any> {
    return this.httpclient.get("http://localhost:1018/cafe/user/userlogin?username=" + username + "&password=" + password);
  }

  userRegister(user: Object): Observable<Object> {
    return this.httpclient.post('http://localhost:1018/cafe/user/register', user);

  }//update profile
  updateUserProfile(userId:any, updatedUserData: User): Observable<User> {
    const url = ("http://localhost:1018/cafe/user/update/"+userId);
    return this.httpclient.put<User>(url, updatedUserData);
  }

  // updateUserProfile(userId: string, updatedUserData: User): Observable<Object> {
  //   return this.httpClient.put("http://localhost:1018/cafe/api/update/"+name,menu,{responseType:'text' as 'json'});
  // }
  changePassword(userId: number, oldPassword: string, newPassword: string): Observable<User> {
    const url = `http://localhost:1018/cafe/user/change-password/${userId}`;
    const params = new HttpParams()
    .set('oldPassword', oldPassword)
    .set('newPassword', newPassword);

  const headers = new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded');

  return this.httpclient.put<User>(url, params.toString(), { headers });
  }
  
  // UserServic
  getCurrentUserId(): number | null {
    const userId = sessionStorage.getItem('userId'); // Replace 'userId' with the actual key you use to store the user ID
    return userId ? +userId : null;
  }


  searchTable(tablerow: string): Observable<any> {
    const url = "http://localhost:1018/cafe/user/search-table?tablerow=" + tablerow;
    console.log("Search Table URL:", url);
    return this.httpclient.get(url).pipe(
      catchError(error => {
        console.error("Error during searchTable request:", error);
        throw error;
      })
    );
  }

  tableBook(id: number): Observable<any> {
    let name = sessionStorage.getItem("name");
    return this.httpclient.get('http://localhost:1018/cafe/user/booktable?id=' + id + "&username=" + name);
  }

  getReservedTable(tableusername: string): Observable<any> {
    return this.httpclient.get("http://localhost:1018/cafe/user/bookedtables?username=" + tableusername);
  }

  getMenuList(): Observable<any> {
    const menuUrl = 'http://localhost:1018/cafe/user/menu'; // Update the URL
  
    return this.httpclient.get(menuUrl);
  }
  getMenuByItemName(name: string): Observable<Menu[]> {
    const url = `http://localhost:1018/cafe/user/menu/name?name=${name}`;
    return this.httpclient.get<Menu[]>(url);
  }

// 

id:any;
  user?: User;
  authenticate(username: string, password: string) {// Step 1: Making an HTTP request to fetch user login data
    this.getUserLogin(username, password).subscribe(
      data => {
        this.user = data;// Assign fetched user data to the 'user' property
      },
      error => {
        console.error("Error during authentication:", error);
      }
    );
   // Step 2: Handling authentication based on fetched user data
    if (this.user) {
         // If 'user' is not undefined (authentication successful)
      console.log(this.user?.username+this.user?.id);
      sessionStorage.setItem('id', this.user.id.toString());
      sessionStorage.setItem('username', username);
      console.log("username:" + username);
      return true;
    } else {
      // If 'user' is undefined (authentication failed)
      return false;
    }
  }

  isUserLoggedIn() {
    let name = sessionStorage.getItem('username')
    console.log(!(name === null))
    return !(name === null)
  }

  logOut() {
    sessionStorage.removeItem('username')
  }
}
