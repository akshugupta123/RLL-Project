import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Menu } from './menu';
import { Admin } from './admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  baseUrl = "http://localhost:1018/cafe/api";

  constructor(private httpClient: HttpClient) { }
  registerAdmin(admin: Admin): Observable<Admin> {
    return this.httpClient.post<Admin>(`http://localhost:1018/cafe/api/register`, admin, {responseType:'text' as 'json'});
  }


  authentication(username: string, password: string) {
   let response=this.httpClient.post("http://localhost:1018/cafe/api/login"+username,password,{responseType:'text' as 'json'});
   if(response!==null){
     sessionStorage.setItem('adminname', username);
    return true;
   }else{
    return false;
   }
   
  }

  isAdminLoggedIn(): boolean {
    const user = sessionStorage.getItem('adminname');
    return user !== null;
  }

  getMenuList(): Observable<Menu[]> {
    return this.httpClient.get<Menu[]>(`${this.baseUrl}/menu`)
      .pipe(
        catchError(error => {
          console.error('Error fetching menu list:', error);
          return throwError(error);
        })
      );
  }
//add menu returns an Observable that emits data of type Object. This indicates that the Observable 
//will emit data in the form of JavaScript objects. The returned Observable can then be subscribed to, 
//and you can handle the emitted data using RxJS operators and functions.
  addMenu(menu: Menu): Observable<Object> {
    return this.httpClient.post(`${this.baseUrl}/create/menu`, menu)
      .pipe(
        catchError(error => {
          console.error('Error adding menu:', error);
          return throwError(error);
        })
      );
  }

  updateMenu(name: string, menu: Menu): Observable<Object> {
    return this.httpClient.put(`${this.baseUrl}/update/menu/${name}`, menu)
      .pipe(
        catchError(error => {
          console.error('Error updating menu:', error);
          return throwError(error);
        })
      );
  }

  getMenuByname(name: string): Observable<Menu[]> {
    return this.httpClient.get<Menu[]>(`${this.baseUrl}/menu/name?name=${name}`)
      .pipe(
        catchError(error => {
          console.error('Error fetching menu by name:', error);
          return throwError(error);
        })
      );
  }

  deleteMenu(name: string): Observable<Object> {
    return this.httpClient.delete(`${this.baseUrl}/delete/menu/${name}`)
      .pipe(
        catchError(error => {
          console.error('Error deleting menu:', error);
          return throwError(error);
        })
      );
  }
/**
 * Sends an HTTP POST request to add tables to the server.
 *
 * @param table The table object to be added.
 * @returns An Observable representing the response from the server.
 * If an error occurs, an error Observable is returned.
 */
  addTables(table: Object): Observable<Object> {
    return this.httpClient.post(`${this.baseUrl}/addtables`, table)
      .pipe( //.pipe(: This is where RxJS operators are applied to the observable returned by the post method.
        catchError(error => {
          console.error('Error adding tables:', error);
          return throwError(error);
        })
      );
  }



  logOut(): void {
    sessionStorage.removeItem('adminname');
  }
}

