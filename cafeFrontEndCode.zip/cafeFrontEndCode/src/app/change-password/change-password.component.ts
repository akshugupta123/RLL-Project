import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';


@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  oldPassword: string = '';
  newPassword: string = '';

  constructor(private userService: UserService, private router: Router) {}

  ngOnInit(): void {
    // Implement your initialization logic here
    // For example, you can check if the user is authenticated before allowing access to this page
    if (!this.userService.isUserLoggedIn()) {
      // Redirect to the login page if the user is not authenticated
      this.router.navigate(['/userlogin']);
    }
  }
  changePassword(): void {
    const userId = this.userService.getCurrentUserId();
    if (userId === null) {
      console.error('User ID not available');
      return;
    }
  
    this.userService.changePassword(userId, this.oldPassword, this.newPassword).subscribe(
      (updatedUser) => {
        // Handle success, e.g., show a success message
        console.log('Password changed successfully:', updatedUser);
        this.router.navigate(['/userlogin']); // Navigate to the user login page
      },
      (error) => {
        // Handle error, e.g., display an error message
        console.error('Error changing password:', error);
      }
    );
  }
}  

  
