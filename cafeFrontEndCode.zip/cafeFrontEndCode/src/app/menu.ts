export class Menu {
    id!: number;
    name!: string;
    itemPrice!: string;
    description!: string
    status!: string;

}
