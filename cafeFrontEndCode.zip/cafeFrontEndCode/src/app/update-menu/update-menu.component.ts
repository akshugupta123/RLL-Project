import { Component, OnInit } from '@angular/core';
import { MenuService } from '../menu.service';
import { Menu } from '../menu';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-menu',
  templateUrl: './update-menu.component.html',
  styleUrls: ['./update-menu.component.css']
})
export class UpdateMenuComponent implements OnInit {

  name!: string;
  menu: Menu = new Menu();
  constructor(private menuService: MenuService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.name = this.route.snapshot.params['name'];

    // this.menuService.getMenuByname(this.name).subscribe((data: any) => {
    //   this.menu = data;
    // }, (error: any) => console.log(error));
  }
  onSubmit(){
    this.menuService.updateMenu(this.name, this.menu).subscribe( data =>{
      this.goToMenuList();
    }
    , (error: any) => console.log(error));
  }
  goToMenuList() {
    this.router.navigate(['/menu']);
  }
 
}