import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin-register',
  templateUrl: './admin-register.component.html',
  styleUrls: ['./admin-register.component.css']
})

export class AdminRegisterComponent implements OnInit {
  
    admin:Admin=new Admin();
    submitted=false;
    constructor(private router:Router,private adminService:AdminService) { }
  
    ngOnInit(): void {
    }
    addItemSave(){
      this.adminService.registerAdmin(this.admin).subscribe(
        data=>{
          this.admin=new Admin();
          this.router.navigate(['/adminlogin']);
        }
      );
    } }