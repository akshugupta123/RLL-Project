export class Admin {
    id: number;
    name: string;
    email: string;
    mobile: string;
    address: string;
    username: string;
    password: string;
  
}
  